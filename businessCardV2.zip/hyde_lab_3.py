UNIVERSITY = 'Temple University'
BUILDING = 'SERC Building'
ADDRESS = '1925 North 12th Street'
CITY = 'Philadelphia PA 19122'

def business_card(first, last, email):
    print(first + ' ' + last)
    print(email)
    print(UNIVERSITY)
    print(BUILDING)
    print(ADDRESS)
    print(CITY)

def user_data():
    first = input('Please enter your first name: ')
    last = input('please enter your last name: ')
    email = input('please enter your email address here: ')
    business_card(first, last, email)

user_data()
