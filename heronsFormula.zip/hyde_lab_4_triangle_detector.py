import math 
def triangle(a, b, c):
    s = (a + b + c) / 2.0
    area = s * (s-a) * (s-b) * (s-c)
    if (a + b) > c and (a + c) > b and (b + c) > a:
        print('IS A TRIANGLE : AREA SQUARED = ' + str(area))
    else:
        print('IS NOT A TRIANGLE : AREA SQUARED = ' + str(area))

def triangle_detector():
    a = float(input('Enter length of side a: '))
    b = float(input('Enter length of side b: '))
    c = float(input('Enter length of side c: '))
    triangle(a, b, c)
    
triangle_detector()