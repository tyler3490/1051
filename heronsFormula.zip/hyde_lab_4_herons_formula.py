import math
def herons_formula(a, b, c):
    s = (a + b + c) / 2.0
    area = s * (s-a) * (s-b) * (s-c)
    if area > 0: 
        print('IS A TRIANGLE : AREA SQUARED = ' + str(area))
    else: 
        print('IS NOT A TRIANGLE : AREA SQUARED = ' + str(area))

def triangle_detector():
    a = float(input('Enter length of side a: '))
    b = float(input('Enter length of side b: '))
    c = float(input('Enter length of side c: '))
    herons_formula(a, b, c)

triangle_detector()