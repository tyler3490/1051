import value_sorter
def is_pair(hand):
    counter = 0
    sorted_values = value_sorter.sort_values(hand)
    for i in range(2, 14):
        if sorted_values.count(i) == 2:
            counter += 1
    if counter == 1:
        return True
    return False  


def is_2_pair(hand):
    counter = 0
    sorted_values = value_sorter.sort_values(hand)
    for i in range(2, 14):
        if sorted_values.count(i) == 2:
            counter += 1
    if counter == 2:
        return True
    return False


def is_3_of_a_kind(hand):
    counter = 0
    sorted_values = value_sorter.sort_values(hand)
    for i in range(2, 14):
        if sorted_values.count(i) == 3:
            counter += 1
    if counter == 1:
        return True
    return False


def is_4_of_a_kind(hand):
    counter = 0
    sorted_values = value_sorter.sort_values(hand)
    for i in range(2, 14):
        if sorted_values.count(i) == 4:
            counter += 1
    if counter == 1:
        return True
    return False


def is_full_house(hand):
    if is_pair(hand) and  is_3_of_a_kind(hand) == True:
        return True
    return False


def is_flush(hand):
    if hand[0].get('suit') == hand[0-1].get('suit') == hand[0-2].get('suit') == hand[0-3].get('suit') == hand[0-4].get('suit'):
        return True
    return False


def is_straight(hand):
    counter = 0
    sorted_values = value_sorter.sort_values(hand)
    previous_number = sorted_values[0]
    for number in sorted_values:
        if number == previous_number + 1:
            counter += 1
            if counter == 4:
                return True
        previous_number = number 
    return False


def is_straight_flush(hand):
    if is_flush(hand) and is_straight(hand):
        return True
    return False


def is_high_card(hand):
    if not is_pair(hand) and not is_2_pair(hand) and not is_3_of_a_kind(hand)\
    and not is_4_of_a_kind(hand) and not is_full_house(hand) and not is_flush(hand)\
    and not is_straight(hand) and not is_straight_flush(hand):
        return True
    else:
        return False

if __name__ == "__main__":
    main()