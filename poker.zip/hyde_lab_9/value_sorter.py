import draw_5_cards
def sort_values(hand):
    values = []
    for i in range(len(hand)):
        values.append(hand[i].get('value'))
    values.sort()
    return values

def main():
    print(sort_values(draw_5_cards.draw_5_cards()))

if __name__ == "__main__":
    main()