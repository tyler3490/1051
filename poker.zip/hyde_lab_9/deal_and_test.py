import playing_cards
import card_tests
import draw_5_cards
def deal_and_test(hand):
    counter = 0
    card_1 = hand[0].get('face') + ' of ' + hand[0].get('suit')
    card_2 = hand[1].get('face') + ' of ' + hand[1].get('suit')
    card_3 = hand[2].get('face') + ' of ' + hand[2].get('suit')
    card_4 = hand[3].get('face') + ' of ' + hand[3].get('suit')
    card_5 = hand[4].get('face') + ' of ' + hand[4].get('suit')
    if card_tests.is_pair(hand) :
        counter = 1
    if card_tests.is_2_pair(hand):
        counter = 2
    if card_tests.is_3_of_a_kind(hand):
        counter = 3
    if card_tests.is_4_of_a_kind(hand):
        counter = 4
    if card_tests.is_full_house(hand):
        counter = 5
    if card_tests.is_flush(hand):
        counter = 6
    if card_tests.is_straight(hand):
        counter = 7
    if card_tests.is_straight_flush(hand):
        counter = 8
    if card_tests.is_high_card (hand):
        counter = 9

    print('{:s}\n{:s}\n{:s}\n{:s}\n{:s}\n{:s}\n'.format('Hand dealt: ', card_1, card_2, card_3, card_4, card_5))
    print('Hand assessment: ')
    if counter == 1:
        print('Pair')
    if counter == 2:
        print('2 Pair')
    if counter == 3:
        print('3 of a Kind')
    if counter == 4:
        print('4 of a Kind')
    if counter == 5:
        print('Full House')
    if counter == 6:
        print('Flush')
    if counter == 7:
        print('Straight')
    if counter == 8:
        print('Straigh Flush')
    if counter == 9:
        print('High Card / None ')

def main():
    deal_and_test(draw_5_cards.draw_5_cards())

if __name__ == "__main__":
    main()