import playing_cards
def draw_5_cards():
    hand = []
    deck = playing_cards.build_deck()
    playing_cards.shuffle(deck)
    for i in range(5):
        hand.append(deck.pop())
    return hand


if __name__ == "__main__":
    main()