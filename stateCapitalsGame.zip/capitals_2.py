def states_capitals_selector():
    states = []
    capitals = []
    states_and_capitals = []
    state_selection = str.title(input('Enter a state to see its capital: '))
    file_input = open('capitals.txt')

    for i in file_input:
        states_and_capitals.append(i.strip())
    for i in states_and_capitals:
        if states_and_capitals.index(i) % 2 == 1:
            capitals.append(i.strip())
        else:
            states.append(i.strip())

    if state_selection in states:
        capital_selection = states.index(state_selection)
        return(capitals[capital_selection])
    else:
        return('Not a valid state.')

def main():
    print(states_capitals_selector())

if __name__ == "__main__":
    main()