import random
def states_capitals_quiz():
    states = []
    capitals = []
    states_and_capitals = []
    file_input = open('capitals.txt')
    for i in file_input:
        states_and_capitals.append(i.strip())
    for i in states_and_capitals:
        if states_and_capitals.index(i) % 2 == 1:
            capitals.append(i.strip())
        else:
            states.append(i.strip())

    answer = str.lower(input('Do you want to be quizzed on states or capitals?: '))
    if answer == 'capitals':
        random_state = random.choice(states)
        capital_guess = str.title(input('Enter the capital of ' + random_state + ': '))
        if capital_guess in capitals and states.index(random_state) == capitals.index(capital_guess):
            print('Correct')
        else: 
            print('Incorrect')
    if answer == 'states':
        random_capital = random.choice(capitals)
        state_guess = str.title(input(random_capital + ' is the capital of what state?: '))
        if state_guess in states and capitals.index(random_capital) == states.index(state_guess):
            print('Correct')
        else: 
            print('Incorrect')

    continue_quiz = str.lower(input('Do you want to play again?: '))
    if continue_quiz == 'yes':
        return True
    else: 
        return False

def main():
    while states_capitals_quiz() == True:
        pass

if __name__ == "__main__":
    main()