def check_start_char(password):
    if password.startswith('*') or password.startswith('&'):
        print('Your password can not start with * or &.')
        return False
    else: 
        return True

if __name__ == '__main__':
    main()