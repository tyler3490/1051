def check_if_same(password_1, password_2):
    if password_1 != password_2:
        print('Your passwords do not match, please re-enter.')
        return False
    else: 
        return True

