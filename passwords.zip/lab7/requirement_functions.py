def check_if_same(password_1, password_2):
    if password_1 != password_2:
        print('Passwords do not match, please re-enter.')
        return False
    else: 
        return True


def check_length(password):
    if len(password) < 8:
        print('Password must be at least 8 characters long.')
        return False
    if len(password) > 8:
        print('Password may only be 8 characters long.')
        return False
    else:
        return True


def contains_alphabetic(password):
    index = 0
    for i in password:
        if i.isalpha():
            index += 1
    if index > 0: 
        return True
    else:
        print('Password must contain at least one letter (A-Z and/or a-z).')
        return False


def contains_numeric(password):
    index = 0
    for i in password:
        if i.isnumeric():
            index += 1
    if index > 0: 
        return True
    else:
        print('Password must contain at least one number (0-9).')
        return False


def contains_not_alpha_or_numeric(password):
    index = 0
    for i in password:
        if i.isnumeric() or i.isalpha():
            index += 0
        else:
            index += 1
    if index > 0: 
        return True
    else:
        print('Password must contain at least one special character (@, $, %, etc.).')
        return False


def check_spaces_dashes(password):
    index = 0
    for i in password:
        if i == ' ' or i == '-':
            index += 1
    if index > 0:
        print('Password can not contain a space or a dash.')
        return False
    else: 
        return True


def check_start_char(password):
    if password.startswith('*') or password.startswith('&'):
        print('Password can not start with * or &.')
        return False
    else: 
        return True


def check_repeating_char(password):
    counter = 0
    index = 0
    for i in password:
        if password[index-1] == password[index-2] == password[index-3]:
            counter += 1
        index += 1
    if counter >= 1:
        print('Password can not have the same 3 characters in a row.')
        return False
    else:
        return True

if __name__ == '__main__':
    main()
