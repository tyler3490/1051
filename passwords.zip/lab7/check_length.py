def check_length(password):
    if len(password) < 8:
        print('Password invalid: your password must be at least 8 characters long.')
        return False
    if len(password) > 8:
        print('Password invalid: your password may only be 8 characters long.')
        return False
    else:
        return True