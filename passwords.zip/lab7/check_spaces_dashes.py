def check_spaces_dashes(password):
    index = 0
    for i in password:
        if i == ' ' or i == '-':
            index += 1
        else:
            index += 0 
    if index > 0:
        print('Your password can not contain a space or a dash.')
        return False
    else: 
        return True

print(check_spaces_dashes('777 7'))