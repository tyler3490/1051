def contains_not_alpha_or_numeric(password):
    index = 0
    for i in password:
        if i.isnumeric() or i.isalpha() == True:
            index += 0
        else:
            index += 1
    if index > 0: 
        return True
    else:
        print('Your password must contain at least one special character (@, $, %, etc.)')
        return False

