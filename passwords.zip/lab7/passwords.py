import requirement_functions


def password_is_valid(password):
    index = 0
    if requirement_functions.check_length(password):
        index += 1
    if requirement_functions.contains_alphabetic(password):
        index += 1
    if requirement_functions.contains_numeric(password):
        index += 1
    if requirement_functions.contains_not_alpha_or_numeric(password): 
        index += 1
    if requirement_functions.check_spaces_dashes(password): 
        index += 1
    if requirement_functions.check_start_char(password):
        index += 1
    if requirement_functions.check_repeating_char(password):
        index += 1
    if index == 7:
            return True
    else:
            return False


def main():
    password1 = input('Enter new password: ')
    password2 = input('Enter new password again: ')
    if requirement_functions.check_if_same(password1, password2):
        if password_is_valid(password1):
                print('New password accepted.')
        else:
                print('Password is invalid.')        


if __name__ == '__main__':
    main()


