def check_repeating_char(password):
    counter = 0
    index = 0
    for i in password:
        if password[index-1] == password[index-2] == password[index-3]:
            counter += 1
        index += 1
        print(password[index-1], password[index-2], password[index-3])
    if counter >= 1:
        print('Password invalid: your password can not have the same 3 characters in a row.')
        return False
    else:
        return True

