def contains_numeric(password):
    index = 0
    for i in password:
        if i.isnumeric() == True:
            index += 1
        else:
            index += 0
    if index > 0: 
        return True
    else:
        print('Your password must contain at least one number (0-9)')
        return False
