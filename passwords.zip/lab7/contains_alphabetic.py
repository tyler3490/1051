def contains_alphabetic(password):
    index = 0
    for i in password:
        if i.isalpha():
            index += 1
        else:
            index += 0
    if index > 0: 
        return True
    else:
        print('Your password must contain at least one letter (A-Z and/or a-z)')
        return False

