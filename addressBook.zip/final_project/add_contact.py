def add_contact_to_address_book(file_to_open):
    with open(file_to_open, 'a') as f:
        try:
                first_name = input('Enter contacts first name: ')
                last_name = input('Enter contacts last name: ')
                email_address = input('Enter contacts email address: ')
                phone_number = input('Enter contacts phone number: ')
                f.write('begin:vcard')
                f.write('\nfn:' + first_name.strip() + ' ' + last_name.strip())
                f.write('\nn:' + last_name.strip() + ';' + first_name.strip())
                f.write('\nemail;internet:' + email_address.strip())
                f.write('\ntel;work:' + phone_number.strip())
                f.write('\nversion:2.1')
                f.write('\nend:vcard\n')
        except PermissionError:
                print('PermissionError, file may be open elsewhere')
                exit(0)
        except FileNotFoundError:
                print('FileNotFoundError')
                exit(0)



def main():
    add_contact_to_address_book('test_address_book.txt')

if __name__ == "__main__":
    main()