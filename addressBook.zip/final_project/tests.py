import unittest
import main
import txt_to_list_of_dicts
import dict_to_txt
import searching_functions_and_menu
import add_contact
import delete_contact
import edit_contact
import print_all_contacts
import line_counter
class TestFunctions(unittest.TestCase):
    def test_txt_to_list_of_dicts(self):
        


    # def test_main(self):


    
    
    # def test_dict_to_txt(self):

    
    
    # def test_searching_functions_and_menu(self):

    
    
    # def test_add_contact(self):

    
    
    # def test_delete_contact(self):

    
    
    # def test_edit_contact(self):

    
    
    # def test_print_all_contacts(self):
        


