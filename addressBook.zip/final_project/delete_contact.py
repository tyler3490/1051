import os
import txt_to_list_of_dicts
def delete_contact(address_book, file_to_open):
    contact_to_delete = input('Enter name of contact to delete: ')
    for i in range(len(address_book)):
        if contact_to_delete == address_book[i]['fn']:
            try:
                with open(file_to_open, 'w') as f:  
                    address_book.pop(i)
                    for i in range(len(address_book)):
                        for k, v in address_book[i].items():
                            f.write(str(k) + ':' + str(v) + '\n')
                return 'Contact has been deleted'
            except PermissionError:
                print('PermissionError, file may be open elsewhere')
                exit(0)
            except FileNotFoundError:
                print('FileNotFoundError')
                exit(0)
    else:
        print('Contact not found')

def main():
    print(delete_contact(txt_to_list_of_dicts.txt_to_list_of_dicts()))


if __name__ == "__main__":
    main()



