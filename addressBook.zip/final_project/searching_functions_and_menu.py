import txt_to_list_of_dicts
import edit_contact
def search_for_name(address_book):
    fn_to_search = input('Enter full name to search: ')
    for i in range(len(address_book)):
        if fn_to_search == address_book[i]['fn']:
            print(address_book[i]['fn'] + '\n' + address_book[i]['email;internet']\
                     + '\n' + address_book[i]['tel;work'])
            edit_contact.edit_contact(address_book, i)
            return address_book[i]['fn'] + '\n' + address_book[i]['email;internet']\
                     + '\n' + address_book[i]['tel;work']
    else: 
        return 'Name not found.'

def search_for_email(address_book):
    email_to_search = input('Enter email to search: ')
    for i in range(len(address_book)):
        if email_to_search == address_book[i]['email;internet']:
            print(address_book[i]['fn'] + '\n' + address_book[i]['email;internet']\
                     + '\n' + address_book[i]['tel;work'])
            edit_contact.edit_contact(address_book, i)
            return address_book[i]['fn'] + '\n' + address_book[i]['email;internet']\
                     + '\n' + address_book[i]['tel;work']
    else: 
        return 'Email not found.'

def search_for_phone_number(address_book):
    phone_number_to_search = input('Enter phone number to search: ')
    for i in range(len(address_book)):
        if phone_number_to_search == address_book[i]['tel;work']:
            print(address_book[i]['fn'] + '\n' + address_book[i]['email;internet']\
                     + '\n' + address_book[i]['tel;work'])
            edit_contact.edit_contact(address_book, i)
            return address_book[i]['fn'] + '\n' + address_book[i]['email;internet']\
                     + '\n' + address_book[i]['tel;work']
    else: 
        return 'Phone number not found.'

def searching_menu():
        print('1) Name')
        print('2) Phone number')
        print('3) Email')
        search_choice = input('What do you want to search for?: ').strip()
        if search_choice == '1':
            print(search_for_name(txt_to_list_of_dicts.txt_to_list_of_dicts('address_book.txt')))
            return True
        if search_choice == '2':
            print(search_for_phone_number(txt_to_list_of_dicts.txt_to_list_of_dicts('address_book.txt')))
            return True
        if search_choice == '3':
            print(search_for_email(txt_to_list_of_dicts.txt_to_list_of_dicts('address_book.txt')))
            return True
        else:
            print('Invalid selection')
            return True 




def main():
    searching_menu()
    # print(search_for_name(txt_to_list_of_dicts.txt_to_list_of_dicts()))
    # print(search_for_email(txt_to_list_of_dicts.txt_to_list_of_dicts()))
    # print(search_for_phone_number(txt_to_list_of_dicts.txt_to_list_of_dicts()))

if __name__ == "__main__":
    main()