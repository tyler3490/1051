import os
def txt_to_list_of_dicts(file_to_open):
    address_book = []
    contact = {}
    try:        
        with open(file_to_open, 'r+') as f:
            for line in f:
                key_value_pair = line.split(':')
                if key_value_pair[0] == 'begin' and contact:
                    address_book.append(contact)
                    contact = {}
                contact[key_value_pair[0]] = key_value_pair[1].strip('\n')
            if contact:
                address_book.append(contact)
    except PermissionError:
        print('PermissionError, file may be open elsewhere')
        exit(0)
    except FileNotFoundError:
        print('FileNotFoundError')
        exit(0)
    return address_book

def main():
    print(txt_to_list_of_dicts())

if __name__ == "__main__":
    main()

    # e = []
    # d = {}
    # with open('address_book.txt', 'r') as f:
    #     for line in f:
    #         key, val = line.split(':')
    #         d[key] = val.strip('\n')
    #         if key == 'end' and d:
    #             e.append(d)
                
    # print (d)   
    # print (e)
