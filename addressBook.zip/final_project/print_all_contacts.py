import txt_to_list_of_dicts
def print_all_contacts(address_book):
    for i in range(len(address_book)):
        print(address_book[i]['fn'] + ', ' + address_book[i]['email;internet'] \
            + ', ' + address_book[i]['tel;work'] + '\n')


def main():
    print_all_contacts(txt_to_list_of_dicts.txt_to_list_of_dicts('address_book.txt'))

if __name__ == "__main__":
    main()

            