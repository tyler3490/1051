def line_counter(file_to_open):
    counter = 0
    with open(file_to_open, 'r') as f:
        for line in f:
            counter += 1
    return counter

def main():
    print(line_counter())


if __name__ == "__main__":
    main()
