import searching_functions_and_menu
import txt_to_list_of_dicts
import add_contact
import print_all_contacts
import delete_contact
def menu():
    print('1) Search contacts.')
    print('2) Enter new contact.')
    print('3) Delete contact.')
    print('4) Print all contacts.')
    print('5) Quit program.')
    choice = input('Please make a selection: ').strip()
    if choice == '1':
        searching_functions_and_menu.searching_menu()
        return True
    if choice == '2':
        add_contact.add_contact_to_address_book('address_book.txt')
        return True
    if choice == '3':
        delete_contact.delete_contact(txt_to_list_of_dicts.txt_to_list_of_dicts('address_book.txt'))
        return True
    if choice == '4':
        print_all_contacts.print_all_contacts(txt_to_list_of_dicts.txt_to_list_of_dicts('address_book.txt'))
        return True
    if choice == '5':
        return False
    else: 
        print('Invalid selection')
        return True

def main():
    should_continue = menu()
    while should_continue:
        should_continue = menu()

if __name__ == "__main__":
    main()