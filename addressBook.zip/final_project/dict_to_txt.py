import os
import txt_to_list_of_dicts
def dict_to_txt(address_book, file_to_open):
    with open(file_to_open, 'w+') as f:
        try:
            for i in range(len(address_book)):
                for k, v in address_book[i].items():
                    f.write(str(k) + ':' + str(v) + '\n')
        except PermissionError:
            print('PermissionError, file may be open elsewhere')
            exit(0)
        except FileNotFoundError:
            print('FileNotFoundError')
            exit(0)


def main():
    dict_to_txt(txt_to_list_of_dicts.txt_to_list_of_dicts())

if __name__ == "__main__":
    main()