import searching_functions_and_menu
import txt_to_list_of_dicts
import dict_to_txt
def edit_contact(address_book, index):
    choice_to_continue = True
    while choice_to_continue:
        choice_to_edit = input('Would you like to edit this contact?: ').strip() 
        if choice_to_edit == 'y':
            print('1) Name')
            print('2) Phone number')
            print('3) Email')
            print('4) Quit')
            edit_selection = input('What do you want to edit?: ').strip()
            if edit_selection == '1':
                first_name = input('Enter new first name: ')
                last_name = input('Enter new last name: ')
                address_book[index]['fn'] = first_name.strip() + ' ' + last_name.strip()
                address_book[index]['n'] = last_name.strip() + ';' + first_name.strip()
                dict_to_txt.dict_to_txt(address_book, 'address_book.txt')
                choice_to_continue = False
                return address_book
            elif edit_selection == '2':
                tel_number = input('Enter new phone number: ')
                address_book[index]['tel;work'] = tel_number.strip()
                dict_to_txt.dict_to_txt(address_book, 'address_book.txt')
                choice_to_continue = False
                return address_book
            elif edit_selection == '3':
                email = input('Enter new email address: ')
                address_book[index]['email;internet'] = email.strip()
                dict_to_txt.dict_to_txt(address_book, 'address_book.txt')
                choice_to_continue = False
                return address_book
            elif edit_selection == '4':
                choice_to_continue = False
            else:
                print('Invalid input')
        elif choice_to_edit == 'n':
            choice_to_continue = False
            return address_book
        else:
            print('Invalid input, please enter \"y\" or \"n\".')


def main():
    # dict_to_txt.dict_to_txt(search_for_name(txt_to_list_of_dicts.txt_to_list_of_dicts()))
    edit_contact(txt_to_list_of_dicts.txt_to_list_of_dicts(), 3)

if __name__ == "__main__":
    main()





