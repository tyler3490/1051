you = 'Tyler'
must = 'Hyde'
make = 'tuj66923@temple.edu'
each = 'Temple'
seperate = 'University'
word = 'SERC'
into = 'Building'
year = '1925'
variable = 'North'
number = '12th'
into ='street'
city = 'Philadelphia'
state = 'PA'
zipcode = '19122'
print (you + ' ' + must)
print (make)
print (each + ' ' + seperate)
print (word + ' ' + into)
print (year + ' ' + variable + ' ' + number + ' ' + into)
print (city + ' ' + state + ' ' + zipcode) 