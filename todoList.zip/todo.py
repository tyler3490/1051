import time
def add_item(todo_list, item):
    item['time_added'] = time.mktime(time.gmtime())
    todo_list.append(item)

def show_completed(todo_list):
    completed_items = []
    for item in todo_list:
        if item['completed'] == True:
            completed_items.append(item)
    return completed_items

def show_outstanding(todo_list):
    outstanding_items = []
    for item in todo_list:
        if item['completed'] == False:
            outstanding_items.append(item)
    return outstanding_items

def remove_completed(todo_list):
    for item in todo_list:
        if item['completed'] == True:
            todo_list.remove(item)
    return todo_list

def show_priority(todo_list, priority_number):
    items_with_priority_number = []
    for item in todo_list:
        if item['priority'] == priority_number:
            items_with_priority_number.append(item)
    return items_with_priority_number

def get_next_item(todo_list):
    return todo_list[0]

if __name__ == "__main__":
    main()