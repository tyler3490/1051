import unittest
import todo
def create_todo_list():
    todo_list = []
    item_1 = {
        'task_name': 'do chores',
        'completed': False,
        'priority': 2,
        'time_added': 0,
    }
    item_2 = {
        'task_name': 'groceries',
        'completed': True,
        'priority': 3,
        'time_added': 0,
    }
    item_3 = {
        'task_name': 'homework',
        'completed': False,
        'priority': 1,
        'time_added': 0,
    }
    todo.add_item(todo_list, item_1)
    todo.add_item(todo_list, item_2)
    todo.add_item(todo_list, item_3)
    return todo_list

class test_todo_list(unittest.TestCase):
    def test_add_item(self):
        todo_list = []
        item_1 = {
            'task_name': 'do chores',
            'completed': False,
            'priority': 2,
            'time_added': 0,
        }
        todo.add_item(todo_list, item_1)
        self.assertEqual(len(todo_list), 1)
        self.assertEqual(todo_list[0]['task_name'], 'do chores')
        self.assertEqual(todo_list[0]['completed'], False)
        self.assertEqual(todo_list[0]['priority'], 2)
        item_2 = {
            'task_name': 'groceries',
            'completed': True,
            'priority': 3,
            'time_added': 0,
        }
        todo.add_item(todo_list, item_2)
        self.assertEqual(len(todo_list), 2)
        self.assertEqual(todo_list[1]['task_name'], 'groceries')
        self.assertEqual(todo_list[1]['completed'], True)
        self.assertEqual(todo_list[1]['priority'], 3)
        item_3 = {
            'task_name': 'homework',
            'completed': False,
            'priority': 1,
            'time_added': 0,
        }
        todo.add_item(todo_list, item_3)
        self.assertEqual(len(todo_list), 3)
        self.assertEqual(todo_list[2]['task_name'], 'homework')
        self.assertEqual(todo_list[2]['completed'], False)
        self.assertEqual(todo_list[2]['priority'], 1)

    def test_show_completed(self):
        todo_list = create_todo_list()
        completed_items = todo.show_completed(todo_list)
        self.assertEqual(len(completed_items), 1)
        self.assertEqual(completed_items[0]['completed'], True)
        self.assertEqual(len(todo_list), 3)

    def test_show_outstanding(self):
        todo_list = create_todo_list()
        outstanding_items = todo.show_outstanding(todo_list)
        self.assertEqual(len(outstanding_items), 2)
        self.assertEqual(outstanding_items[0]['completed'], False)
        self.assertEqual(outstanding_items[1]['completed'], False)
        self.assertEqual(len(todo_list), 3)

    def test_remove_completed(self):
        todo_list = create_todo_list()
        completed_items_removed = todo.remove_completed(todo_list)
        self.assertEqual(len(completed_items_removed), 2)
        self.assertEqual(completed_items_removed[0]['completed'], False)
        self.assertEqual(completed_items_removed[1]['completed'], False)
        self.assertEqual(len(todo_list), 2)

    def test_show_priority(self):
        todo_list = create_todo_list()
        items_with_priority_number = todo.show_priority(todo_list, 3)
        self.assertEqual(len(items_with_priority_number), 1)
        self.assertEqual(items_with_priority_number[0]['priority'], 3)
        self.assertEqual(len(todo_list), 3)

    def test_get_next_item(self):
        todo_list = create_todo_list()
        next_item = todo.get_next_item(todo_list)
        self.assertEqual(next_item, todo_list[0])
        self.assertEqual(len(todo_list), 3)

if __name__ == "__main__":
    unittest.main()


