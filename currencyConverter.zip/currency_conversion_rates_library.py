#... to USD
def USD_to_USD(amount):
    return amount / 1 
def EUR_to_USD(amount):
    return amount / 0.85
def GBP_to_USD(amount):
    return amount / 0.76
def JPY_to_USD(amount):
    return amount / 112.91
def BRL_to_USD(amount):
    return amount / 4.08

#USD to ...
def USD_to_USD(amount):
    return amount * 1 
def USD_to_EUR(amount):
    return amount * 0.85
def USD_to_GBP(amount):
    return amount * 0.76
def USD_to_JPY(amount):
    return amount * 112.91
def USD_to_BRL(amount):
    return amount * 4.08









