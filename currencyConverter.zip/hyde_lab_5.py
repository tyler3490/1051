import currency_conversion_rates_library

def to_USD_converter(amount, currency_you_have):
    if currency_you_have == 'USD':
        return currency_conversion_rates_library.USD_to_USD(amount)
    elif currency_you_have == 'EUR':
        return currency_conversion_rates_library.EUR_to_USD(amount)
    elif currency_you_have == 'GBP':
        return currency_conversion_rates_library.GBP_to_USD(amount)
    elif currency_you_have == 'JPY': 
        return currency_conversion_rates_library.JPY_to_USD(amount)
    elif currency_you_have == 'BRL':
        return currency_conversion_rates_library.BRL_to_USD(amount)

def from_USD_converter(amount, currency_you_want):
    if currency_you_want == 'USD':
        return currency_conversion_rates_library.USD_to_USD(amount)
    elif currency_you_want == 'EUR':
        return currency_conversion_rates_library.USD_to_EUR(amount)
    elif currency_you_want == 'GBP': 
        return currency_conversion_rates_library.USD_to_GBP(amount)
    elif currency_you_want == 'JPY':
        return currency_conversion_rates_library.USD_to_JPY(amount)
    elif currency_you_want == 'BRL': 
        return currency_conversion_rates_library.USD_to_BRL(amount)

def main():
    amount = float(input('How much money do you have?: '))
    currency_you_have = input('What currency do you have? (USD, EUR, GBP, JPY, BRL): ')
    currency_you_want = input('What currency do you want? (USD, EUR, GBP, JPY, BRL): ')
    converted_currency = from_USD_converter(to_USD_converter(amount, currency_you_have), currency_you_want)
    print_converted_currency(amount, currency_you_have, currency_you_want, converted_currency)

def print_converted_currency(amount, currency_you_have, currency_you_want, converted_currency):
    print('Your', str(round(amount, 2)), currency_you_have, 'is worth', str(round(converted_currency, 2)), currency_you_want)

if __name__ == '__main__':
    main()



