import random

def number_selector(n):
    two = 0
    three = 0
    four = 0 
    five = 0
    six = 0
    seven = 0
    eight = 0 
    nine = 0
    ten = 0 
    eleven = 0 
    twelve = 0
    for i in range(1, n +1):
        number = random.randint(2, 12)
        if number == 2:
            two += 1
        elif number == 3:
            three += 1
        elif number == 4:
            four += 1
        elif number == 5:
            five += 1
        elif number == 6:
            six += 1
        elif number == 7:
            seven += 1
        elif number == 8:
            eight += 1
        elif number == 9:
            nine += 1
        elif number == 10:
            ten += 1
        elif number == 11:
            eleven += 1
        elif number == 12:
            twelve += 1
    print('{:>10s}{:>18s}{:>25s}{:>15s}{:>20s}'.format('Number', 'Times Selected', '% of total selections', 'Expected %', 'Difference in %'))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(2, two, (two / i) * 100, 9.09, (two / i) * 100 - 9.09)) 
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(3, three, (three / i) * 100, 9.09, (three / i) * 100 - 9.09))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(4, four, (four / i) * 100, 9.09, (four / i) * 100 - 9.09))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(5, five, (five / i) * 100, 9.09, (five / i) * 100 - 9.09))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(6, six, (six / i) * 100, 9.09, (six / i) * 100 - 9.09))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(7, seven, (seven / i) * 100, 9.09, (seven / i) * 100 - 9.09))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(8, eight, (eight / i) * 100, 9.09, (eight / i) * 100 - 9.09))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(9, nine, (nine / i) * 100, 9.09, (nine / i) * 100 - 9.09))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(10, ten, (ten / i) * 100, 9.09, (ten / i) * 100 - 9.09))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(11, eleven, (eleven / i) * 100, 9.09, (eleven / i) * 100 - 9.09))
    print('{:>10d}{:>18d}{:>25.2f}{:>15.2f}{:>20.2f}'.format(12, twelve, (twelve / i) * 100, 9.09, (twelve / i) * 100 - 9.09))
    print('Total iterations:', i)

def main():
    iterations = int(input('Enter the number of times you want to select a random number: '))
    number_selector(iterations)

if __name__ == '__main__':
    main()