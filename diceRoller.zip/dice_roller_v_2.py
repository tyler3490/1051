import random

def two_dice():
    d1 = random.randint(1, 6)
    d2 = random.randint(1, 6)
    total = d1 + d2
    return total

def dice_roller(n):
    two = 0
    three = 0
    four = 0 
    five = 0
    six = 0
    seven = 0
    eight = 0 
    nine = 0
    ten = 0 
    eleven = 0 
    twelve = 0
    for i in range(1, n +1):
        roll = two_dice()
        if roll == 2:
            two += 1
        elif roll == 3:
            three += 1
        elif roll == 4:
            four += 1
        elif roll == 5:
            five += 1
        elif roll == 6:
            six += 1
        elif roll == 7:
            seven += 1
        elif roll == 8:
            eight += 1
        elif roll == 9:
            nine += 1
        elif roll == 10:
            ten += 1
        elif roll == 11:
            eleven += 1
        elif roll == 12:
            twelve += 1
    print('{:>10s}{:>18s}{:>20s}{:>15s}{:>20s}'.format('Number', 'Times Rolled', '% of total rolls', 'Expected %', 'Difference in %'))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(2, two, (two / i) * 100, 2.78, (two / i) * 100 - 2.78))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(3, three, (three / i) * 100, 5.56, (three / i) * 100 - 5.56))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(4, four, (four / i) * 100, 8.33, (four / i) * 100 - 8.33))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(5, five, (five / i) * 100, 11.11, (five / i) * 100 - 11.11))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(6, six, (six / i) * 100, 13.89, (six / i) * 100 - 13.89))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(7, seven, (seven / i) * 100, 16.67, (seven / i) * 100 - 16.67))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(8, eight, (eight / i) * 100, 13.89, (eight / i) * 100 - 13.89))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(9, nine, (nine / i) * 100, 11.11, (nine / i) * 100 - 11.11))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(10, ten, (ten / i) * 100, 8.33, (ten / i) * 100 - 8.33))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(11, eleven, (eleven / i) * 100, 5.56, (eleven / i) * 100 - 5.56))
    print('{:>10d}{:>18d}{:>20.2f}{:>15.2f}{:>20.2f}'.format(12, twelve, (twelve / i) * 100, 2.78, (twelve / i) * 100 - 2.78))
    print('Total iterations:', i)

def main():
    iterations = int(input('Enter the number of times you want to roll the dice: '))
    dice_roller(iterations)

if __name__ == '__main__':
    main()
